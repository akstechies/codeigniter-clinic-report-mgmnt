</div>
  <!-- /.content-wrapper -->
  <footer class="main-footer" style="text-align: center;">
    <strong>Copyright &copy; 2020 <a href="https://www.skyracle.com/">SKYRACLE</a>.</strong>
    All rights reserved.
    
  </footer>

  
  <!-- /.control-sidebar -->
</div>